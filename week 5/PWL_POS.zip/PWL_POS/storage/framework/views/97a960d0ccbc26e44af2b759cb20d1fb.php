



<?php $__env->startSection('subtitle', 'Kategori'); ?>
<?php $__env->startSection('content_header_title', 'Home'); ?>
<?php $__env->startSection('content_header_subtitle', 'Kagegori'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <div class="col-md-12 row">
                    <div class="col-6 d-flex justify-content-start">
                        <span>Manage Kategori</span>
                    </div>
                    <div class="col-6 d-flex justify-content-end">
                        <a href="/kategori/create" class="btn btn-primary">Add Kategori</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php echo e($dataTable->table()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PWL_2025\week 5\PWL_POS\resources\views/kategori/index.blade.php ENDPATH**/ ?>