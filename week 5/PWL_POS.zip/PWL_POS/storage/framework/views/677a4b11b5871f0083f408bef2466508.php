<footer class="main-footer">
    <?php echo $__env->yieldContent('footer'); ?>
</footer><?php /**PATH C:\xampp\htdocs\PWL_2025\week 5\PWL_POS\vendor\jeroennoten\laravel-adminlte\src/../resources/views/partials/footer/footer.blade.php ENDPATH**/ ?>