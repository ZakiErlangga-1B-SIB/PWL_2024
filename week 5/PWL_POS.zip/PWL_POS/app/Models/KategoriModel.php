<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KategoriModel extends Model
{
    use HasFactory;

    protected $table = 'm_kategori'; // Pastikan nama tabel sesuai
    protected $primaryKey = 'kategori_id';
    public $timestamps = false; // Sesuaikan dengan database kamu

    protected $fillable = [
        'kategori_kode',
        'kategori_nama',
        'created_at',
        'updated_at'
    ];
}
